package Airline;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class DBConnection {
	protected static String userType;
	protected static Statement stmt = null;
	protected static Connection conn = null;

	// JDBC driver name and database URL
	protected static String JDBC_DRIVER;  
	protected static String DB_URL;

	// Database credentials
	protected static String USER;
	protected static String PASS;
		
	public DBConnection() {
	    connect();
	}
	
	protected static Connection connect() {
		try {
			JDBC_DRIVER = "com.mysql.jdbc.Driver";
			DB_URL = "jdbc:mysql://localhost:3306/flightreservation?useSSL=false";
			USER = "root";
			PASS = "ASDFGHJKL";
			
			// STEP 2: Register JDBC driver
			Class.forName(JDBC_DRIVER).newInstance();

			// STEP 3: Open a connection
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = conn.createStatement();
			
		} catch (Exception e) {
	        System.out.println(e);
	    }
	    return conn;
	}
	
	
	// Only run once to set up table
	public static void main(String[] args) {
		try {
			connect();
			
			// Create database:
			//createDB();

			// Create tables:
			createuserTable();
			c reateFlightsTable("domestic_flights");
			createFlightsTable("international_flights");
			createCustomerFlightsTable();
      
			// Insert initial table data:
			insertuserTable();			
			insertDomesticFlightsTable();
			insertInternationalFlightsTable();
      
			// Select table data:
			selectuserTable();
			selectFlightsTable("domestic_flights");
			selectFlightsTable("international_flights");
			selectCustomerFlightsTable();
		} catch (Exception e) {
	        System.out.println(e);
	    }
	}
	
	
	/**
	 * =======================================
	 *  Methods used to create the database 
	 *  and tables, and insert initial values
	 * =======================================
	 */
	

	protected static void createDB() throws SQLException {
		String sql = "CREATE DATABASE IF NOT EXISTS airline_system";
		stmt.executeUpdate(sql);
	}
	
	
	protected static void createuserTable() 
			throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS user " +
				" (id INTEGER NOT NULL AUTO_INCREMENT, " +
				" first VARCHAR(255), " + 
				" middle VARCHAR(255), " + 
				" last VARCHAR(255), " + 
				" street VARCHAR(255), " + 
				" city VARCHAR(255), " + 
				" state VARCHAR(255), " + 
				" zip CHAR(5), " + 
				" username VARCHAR(255), " + 
				" password VARCHAR(255), " + 
				" email VARCHAR(255), " + 
				" SSN VARCHAR(11), " + 
				" sQuestion VARCHAR(255), " + 
				" userType VARCHAR(15), " + 
				" PRIMARY KEY ( id ))";
		stmt.executeUpdate(sql);
		
		// Set user id
		sql = "ALTER TABLE user AUTO_INCREMENT = 1001";
		stmt.executeUpdate(sql);
	}
	
	
	protected static void insertuserTable() 
			throws SQLException {
		String sql = "INSERT INTO user (`first`, `middle`, "
				+ "`last`, `street`, `city`, `state`, `zip`, `username`, "
				+ "`password`, `email`, `SSN`, `sQuestion`, `userType`) " 
				+ "VALUES ('Brandon', '', 'Tolson', '1808 Chalmers Oak Ct.', "
				+ "'Lawrenceville', 'GA', '30043', 'btolson1', 'pwd1', "
				+ "'btolson@gmail.com', '123456789', 'rex', 'admin'), "
				+ "('Eric', '', 'Theng', '164 Penss Ave', 'Atlanta', "
				+ "'GA', '30044', 'etheng', 'pwd2', 'ethen@yahoo.com', '1234423323', "
				+ "'Ale', 'admin') " + "ON DUPLICATE KEY UPDATE "
	      		+ "`username` = `username`";
	    stmt.executeUpdate(sql);
	}
	
	
	protected static void selectuserTable() 
			throws SQLException {
		System.out.println("Selecting user table...");	    
	    String sql = "SELECT id, first, middle, last, street, city, "
	    		+ "state, zip, username, password, email, SSN, "
	    		+ "sQuestion, userType FROM user";
	    ResultSet rs = stmt.executeQuery(sql);

	    printUserTable(rs);
	    rs.close();
	}
	
	
	protected static void printUserTable(ResultSet rs) 
			throws SQLException {
		while (rs.next()) {
			// Retrieve by column name
			int id  = rs.getInt("id");
	        String first = rs.getString("first");
	        String middle = rs.getString("middle");
	        String last = rs.getString("last");
	        String street = rs.getString("street");
	        String city = rs.getString("city");
	        String state = rs.getString("state");
	        String zip = rs.getString("zip");
	        String username = rs.getString("username");
	        String password = rs.getString("password");
	        String SSN = rs.getString("SSN");
	        String sQuestion = rs.getString("sQuestion");
	        String userType = rs.getString("userType");
	        
	        // Display values
	        System.out.println("ID: " + id + ", First: " + first + ", "
	        		+ "Middle: " + middle + " Last: " + last + " Address: " 
	        		+ street + " " + city + ", " + state + " " + zip 
	        		+ " Username: " + username + " Password: " + password 
	        		+ " SSN: " + SSN + " Security Question: " + sQuestion 
	        		+ " User Type: " + userType);
		}
	}
	
	
	protected static void createFlightsTable(String tableName) 
			throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS " + tableName 
				+ " (id INTEGER NOT NULL AUTO_INCREMENT, "
				+ "start VARCHAR(45), dest VARCHAR(45), "
				+ "time VARCHAR(45), pricePerTicket DOUBLE, "
				+ "totalSeats INTEGER NULL, availableSeats INTEGER NULL, "
				+ "PRIMARY KEY ( id ))";
		stmt.executeUpdate(sql);
		
		// Set flight id
		if (tableName == "domestic_flights") {
			sql = "ALTER TABLE domestic_flights AUTO_INCREMENT = 1001";
		}
		else {
			sql = "ALTER TABLE international_flights AUTO_INCREMENT = 2001";
		}
		stmt.executeUpdate(sql);
	}
	
	
	protected static void insertDomesticFlightsTable() 
			throws SQLException {
		String sql = "INSERT INTO domestic_flights (`start`, `dest`, `time`, `pricePerTicket`, "
				+ "`totalSeats`, `availableSeats`) " 
				+ "VALUES ('Atlanta, Georgia', 'Anchorage, Alaska', '4:50a', 375, 100, 100), "
				+ "('Atlanta, Georgia', 'Boston, Massachusetts', '9:15a', 205, 100, 100), "
				+ "('Atlanta, Georgia', 'Chicago, Illinois', '8:30a', 210, 100, 100), "
				+ "('Atlanta, Georgia', 'Cleveland, Ohio', '8:45p', 215, 100, 100), "
				+ "('Atlanta, Georgia', 'Los Angeles, California', '10:00a', 315, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Dallas, Texas', '6:30a', 230, 100, 100), " 
	      		+ "('Atlanta, Georgia', 'Detroit, Michigan', '4:30p', 290, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Honolulu, Hawaii', '9:15a', 400, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Kansas City, Missouri', '12:25p', 265, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Las Vegas, Nevada', '3:10p', 340, 100, 100), "
				+ "('Atlanta, Georgia', 'Miami, Florida', '1:30p', 195, 100, 100), "
				+ "('Atlanta, Georgia', 'Minneapolis, Minnesota', '7:30a', 285, 100, 100), "
				+ "('Atlanta, Georgia', 'Nashville, Tennessee', '5:35a', 180, 100, 100), "
	      		+ "('Atlanta, Georgia', 'New York City, New York', '5:35a', 280, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Phoenix, Arizona', '1:50p', 305, 100, 100), "
				+ "('Atlanta, Georgia', 'Salt Lake City, Utah', '2:30p', 310, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Seattle, Washington', '11:25a', 325, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Washington D.C.', '1:45p', 260, 100, 100) " 
	      		+ "ON DUPLICATE KEY UPDATE `id` = `id`";
	    stmt.executeUpdate(sql);
	}

	
	protected static void insertInternationalFlightsTable() 
			throws SQLException {
		String sql = "INSERT INTO international_flights (`start`, `dest`, `time`, `pricePerTicket`, "
				+ "`totalSeats`, `availableSeats`) " 
				+ "VALUES ('Atlanta, Georgia', 'London, England', '7:30a', 375, 100, 100), "
				+ "('Atlanta, Georgia', 'Dubai, UAE', '9:15a', 405, 100, 100), "
				+ "('Atlanta, Georgia', 'Tehran, Iran', '8:30a', 410, 100, 100), "
				+ "('Atlanta, Georgia', 'Lahore, Pakistan', '6:45p', 415, 100, 100), "
				+ "('Atlanta, Georgia', 'Sydney, Australia', '10:00a', 420, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Bombay, India', '3:45a', 470, 100, 100), " 
	      		+ "('Atlanta, Georgia', 'Tokyo, Japan', '4:30p', 495, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Shanghai, China', '9:15a', 500, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Berlin, Germany', '12:25p', 365, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Paris, France', '5:35a', 340, 100, 100), "
				+ "('Atlanta, Georgia', 'Cancun, Mexico', '1:30p', 215, 100, 100), "
				+ "('Atlanta, Georgia', 'Zurich, Switzerland', '5:35a', 385, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Stockholm, Sweden', '3:10p', 400, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Oslo, Norway', '1:50p', 385, 100, 100), "
				+ "('Atlanta, Georgia', 'Toronto, Canada', '5:30p', 310, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Dublin, Ireland', '11:45a', 425, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Sao Paulo, Brazil', '7:30a', 385, 100, 100), "
	      		+ "('Atlanta, Georgia', 'Madrid, Spain', '4:05p', 445, 100, 100) " 
	      		+ "ON DUPLICATE KEY UPDATE `id` = `id`";
	    stmt.executeUpdate(sql);
	}
	
	
	protected static void selectFlightsTable(String tableName) 
			throws SQLException {
		System.out.println("\nSelecting " + tableName + " table...");	    
	    String sql = "SELECT id, start, dest, time, pricePerTicket, totalSeats, "
	    		+ "availableSeats FROM " + tableName;
	    ResultSet rs = stmt.executeQuery(sql);

	    printFlightsTable(rs);
	    rs.close();
	}
	
	
	protected static void createCustomerFlightsTable() 
			throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS customer_flights " +
				" (id INTEGER NOT NULL AUTO_INCREMENT, " +
				" username VARCHAR(255), " + 
				" fID VARCHAR(255), " + 
				" fStart VARCHAR(255), " + 
				" fDest VARCHAR(255), " + 
				" fTime VARCHAR(255), " + 
				" fDate DATE NULL, " + 
				" price DOUBLE NULL, " + 
				" adults INTEGER NULL, " + 
				" children INTEGER NULL, " + 
				" infants INTEGER NULL, " + 
				" pTotal DOUBLE NULL, " +
				" type VARCHAR(225), "
				+ "PRIMARY KEY ( id ))";
		stmt.executeUpdate(sql);
		
		// Set user id
		sql = "ALTER TABLE user AUTO_INCREMENT = 1001";
		stmt.executeUpdate(sql);
	}

	
	protected static void selectCustomerFlightsTable() 
			throws SQLException {
		System.out.println("\nSelecting customer_flights table...");	    
	    String sql = "SELECT id, username, fID, fStart, fDest, fTime, "
	    		+ "fDate, price, adults, children, infants, pTotal, type "
			+ "FROM customer_flights";
	    ResultSet rs = stmt.executeQuery(sql);

	    printCustomerFlightsTable(rs);
	    rs.close();
	}
	
	
	protected static void printCustomerFlightsTable(ResultSet rs) 
			throws SQLException {
		while (rs.next()) {
			// Retrieve by column name
			int id  = rs.getInt("id");
			String username = rs.getString("username");
			int fID  = rs.getInt("fID");
	        String start = rs.getString("fStart");
	        String dest = rs.getString("fDest");
	        String time = rs.getString("fTime");
	        String date = rs.getString("fDate");
	        double pricePerTicket = rs.getDouble("price");
	        int adults = rs.getInt("adults");
	        int children = rs.getInt("children");
	        int infants = rs.getInt("infants");
	        double totalPrice = rs.getDouble("pTotal");
	        
	        // Display values
	        System.out.println("ID: " + id + " Username: " + username 
	        		+ " Flight ID: " + fID + " To: " + start + " From: " 
	        		+ dest + " Time: " + time + " Date: " + date 
	        		+ " Ticket Price: " + pricePerTicket + " Adults: " 
	        		+ adults + " Children: " + children + " Infants: " 
	        		+ infants + " Total Price: " + totalPrice);
		}
	}

	
	protected static void printFlightsTable(ResultSet rs) 
			throws SQLException {
		while (rs.next()) {
			// Retrieve by column name
			int id  = rs.getInt("id");
	        String start = rs.getString("start");
	        String dest = rs.getString("dest");
	        String time = rs.getString("time");
	        double pricePerTicket = rs.getDouble("pricePerTicket");
	        int totalSeats = rs.getInt("totalSeats");
	        int availableSeats = rs.getInt("availableSeats");
	        
	        // Display values
	        System.out.println("ID: " + id + ", To: " + start + ", "
	        		+ "From: " + dest + " Time: " + time + " Ticket Price: " 
	        		+ pricePerTicket + " Total Seats: " + totalSeats 
	        		+ " Available Seats: " + availableSeats);
		}
	}
	
	
	/**
	 * =================================
	 *  Methods invoked by the program 
	 * =================================
	 */
	
	protected String getUserType() {
		return userType;
	}
	
	
	protected boolean isValidLogin(String username, String password) {
		try {
		    if (username != null && password != null) {
		    	String sql = "SELECT id, username, password, userType FROM "
		    			+ "user WHERE username='" + username + "' AND "
		    			+ "password='" + password + "'";
		    	ResultSet rs = stmt.executeQuery(sql);
		    	if (rs.next()) {
		    		String dbUsername = rs.getString("username");
		    		String dbPassword = rs.getString("password");
		    		userType = rs.getString("userType");

		    		if (dbUsername.equals(username) && dbPassword.equals(password)) {
		    			return true;
		    		}
		    	}
		    	rs.close();
		    }
		} catch (SQLException err) {
			JOptionPane.showMessageDialog(null, err.getMessage());
		}
		return false;					
	}
	
	
	/**
	 * The user registration can only create new customer accounts
	 * New admin accounts can only be created by other admins
	 */
	protected boolean registerNewUser(String[] userInput) {
		try {
			String sql = "INSERT INTO user (`first`, `middle`, `last`, "
					+ "`street`, `city`, `state`, `zip`, `username`, `password`, "
					+ "`email`, `SSN`, `sQuestion`, `userType`) " + "VALUES ('" 
					+ userInput[0] + "', '" + userInput[1] + "', '" + userInput[2] 
					+ "', '" + userInput[3] + "', '" + userInput[4] + "', '" 
					+ userInput[5] + "', '" + userInput[6] + "', '" + userInput[7] 
					+ "', '" + userInput[8] + "', '" + userInput[9] + "', '" 
					+ userInput[10] + "', '" + userInput[11] + "', 'customer')";
			stmt.executeUpdate(sql);
			JOptionPane.showMessageDialog(null, "Account successfully created");
			return true;
		} catch (SQLException err) {
			JOptionPane.showMessageDialog(null, err.getMessage());
		}
		return false;
	}

	
	protected String getStartColumn(String tableName, String columnName) {
		String departCity = null;
		try {
			String sql = "SELECT " + columnName + " FROM " + tableName;
		    ResultSet rs = stmt.executeQuery(sql);
		    
		    if (rs.next()) {
		        departCity = rs.getString("start");
		    }
		    rs.close();
		} catch (SQLException e) {
		    e.printStackTrace();
		}
		return departCity;
	}
	
	
	protected List<String> getDestColumn(String tableName, String columnName) {
		List<String> destCity = new ArrayList<String>();
		String[] dest = new String[40];
		try {
			String sql = "SELECT " + columnName + " FROM " + tableName;
		    ResultSet rs = stmt.executeQuery(sql);
		    
		    destCity.add("Select"); // Set default value
		    int counter = 1;
		    while (rs.next()) {
		        dest[counter] = rs.getString("dest");	        
		        destCity.add(dest[counter]);
		        counter++;
		    }
		} catch (SQLException e) {
		    e.printStackTrace();
		}
		return destCity;
	}
	
	
	protected String[] getFlightInfo(String tableName, String[] flightInput) {
		String[] flight = new String[7];
		try {
			String sql = "SELECT id, start, dest, time, pricePerTicket, "
					+ "totalSeats, availableSeats FROM " + tableName 
					+ " WHERE dest='" + flightInput[1] + "'";
		    ResultSet rs = stmt.executeQuery(sql);
		    
		    while (rs.next()) {
		        flight[0] = rs.getString("id");
		        flight[1] = rs.getString("start");
		        flight[2] = rs.getString("dest");
		        flight[3] = rs.getString("time");
		        flight[4] = rs.getString("pricePerTicket");
		        flight[5] = rs.getString("totalSeats");
		        flight[6] = rs.getString("availableSeats");		        
		    }
		    rs.close();
		} catch (SQLException e) {
		    e.printStackTrace();
		}
		return flight;
	}
	
	
	protected int checkForConflicts(String[] flight, String[] bookingInfo, 
			String username) {
		try {
			// Check for duplicate flight
			String sql = "SELECT * FROM customer_flights WHERE username = '" 
					+ username + "' AND fID='" + flight[0] + "' AND fDest='" 
					+ bookingInfo[1] + "' AND fDate='" + bookingInfo[2] + "'";
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String user = rs.getString("username");
				String id = rs.getString("fID");
				String dest = rs.getString("fDest");
				String date = rs.getString("fDate");

				if (user.equals(username) && id.equals(flight[0]) 
						&& dest.equals(bookingInfo[1]) 
						&& date.equals(bookingInfo[2])) {
					return 1; 
				}
			}
			
			// Check for scheduling conflict
			sql = "SELECT * FROM customer_flights WHERE fDate='" + bookingInfo[2] + "'";
			rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String user = rs.getString("username");
				String date = rs.getString("fDate");

				if (user.equals(username) && date.equals(bookingInfo[2])) {
					return 2;
				}
			}
			rs.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return 0;
	}
	
	
	protected boolean bookNewFlight(String tableName, String[] flight, String date, 
			int totalCost, int nAdults, int nChildren, int nInfants, String username, 
			int available, int seatsWanted) {
		try {
			String sql = "INSERT INTO customer_flights (`username`, `fID`, `fStart`, "
					+ "`fDest`, `fTime`, `fDate`, `price`, `adults`, `children`, "
					+ "`infants`, `pTotal`, `type`) " + "VALUES ('" + username + "', '" + flight[0] 
					+ "', '" + flight[1]  + "', '" + flight[2] + "', '" + flight[3] + "', '" 
					+ date + "', '" + flight[4] + "', '" + nAdults + "', '" + nChildren 
					+ "', '" + nInfants + "', '" + totalCost + "', '" + tableName + "')";
			stmt.executeUpdate(sql);
			
			// Decrease the number of available seats
			available -= seatsWanted;
			sql = "UPDATE " + tableName + " SET availableSeats='" + available 
					+ "' WHERE id='" + flight[0] + "'";
			stmt.executeUpdate(sql);
			
			JOptionPane.showMessageDialog(null, "Flight successfully booked");
			return true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return false;
	}
	
	
	protected List<String> getCustBookings(String username) {
		List<String> custBookings = new ArrayList<String>();
		String[] row = new String[15];
		DecimalFormat df = new DecimalFormat("#.00");
		try {
			String sql = "SELECT * FROM customer_flights WHERE username='" 
					+ username + "'";
			ResultSet rs = stmt.executeQuery(sql);
			int i = 0;
			
			while (rs.next()) {			
				int id  = rs.getInt("id");
		        String start = rs.getString("fStart");
		        String dest = rs.getString("fDest");
		        String time = rs.getString("fTime");
		        String date = rs.getString("fDate");
		        double price = rs.getDouble("price");
		        int adults = rs.getInt("adults");
		        int children = rs.getInt("children");
		        int infants = rs.getInt("infants");
		        double total = rs.getDouble("pTotal");
		        
		        String str = "From: " + start + " | To: " + dest + " | Time: " 
		        		+ time + " | Date: " + date + " | Ticket Price: $" 
		        		+ df.format(price) + " | Adults: " + adults + " | ";
		        if (children > 0) {
		        	str += "Children: " + children + " | ";
		        }
		        if (infants > 0) {
		        	str += "Infants: " + infants + " | ";
		        }
		        str += "Total: $" + df.format(total) + " | ID: " + id + " ";
		        row[i] = str;
		        
		        // Display values
		        System.out.println(row[i]);
		        custBookings.add(row[i]);
		        i++;
			}

			rs.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return custBookings;
	}
	
	
	protected void deleteCustBooking(String id) {
		String tableName = "";
		int fID = 0;
		int adults = 0;
		int children = 0;
		int available = 0;
		try {
			// Retrieve the selected flight and num of passengers
			String sql = "SELECT * FROM customer_flights WHERE id='" + id + "'";
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				fID = rs.getInt("fID");
				tableName = rs.getString("type");
				adults  = rs.getInt("adults");
				children  = rs.getInt("children");
			}
			
			// Determine the number of seats the user booked			
			sql = "SELECT * FROM " + tableName + " WHERE id='" + fID + "'";
			rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				available  = rs.getInt("availableSeats");				
			}
			
			// Delete flight reservation
			sql = "DELETE FROM customer_flights WHERE id='" + id + "'";
			stmt.executeUpdate(sql);
			
			// Decrease the number of available seats
			int seatsWanted = adults + children;
			available -= seatsWanted;
			sql = "UPDATE " + tableName + " SET availableSeats='" + available 
					+ "' WHERE id='" + fID + "'";
			stmt.executeUpdate(sql);
			JOptionPane.showMessageDialog(null, "Flight successfully deleted");

		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	
	// Admin function
	protected boolean addNewFlight(String tableName, String[] flight) {
		try {
			String sql = "INSERT INTO " + tableName + " (`start`, `dest`, `time`, "
					+ "`pricePerTicket`, `totalSeats`, `availableSeats`) " + 
					"VALUES ('" + flight[0] + "', '" + flight[1] + "', '" + 
					flight[2] + "', '" + flight[3] + "', '" + flight[4] + 
					"', '" + flight[5] + "')";
			
			stmt.executeUpdate(sql);
			JOptionPane.showMessageDialog(null, "Flight successfully added");
			return true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return false;
	}
	
	
	// Admin function
	protected boolean updateFlight(String tableName, String[] flight, String id) {
		try {
			String sql = "UPDATE " + tableName + " SET " + flight[1] + "='" 
					+ flight[2] + "' WHERE id='" + id + "'";
			stmt.executeUpdate(sql);
			JOptionPane.showMessageDialog(null, "Flight successfully updated");
			return true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return false;
	}
	
	
	protected List<String> getAllFlights() {
		List<String> flights = new ArrayList<String>();
		String[] row = new String[65];
		try {
			flights.add("Select"); // Set default value
			String sql = "SELECT * FROM domestic_flights";
			ResultSet rs = stmt.executeQuery(sql);
			int i = 0;
			
			while (rs.next()) {
				String dest = rs.getString("dest");
				String id = rs.getString("id");
				
		        row[i] = "Destination: " + dest + " | ID: " + id + "";
		        flights.add(row[i]);
		        i++;
			}
			
			sql = "SELECT * FROM international_flights";
			rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				String dest = rs.getString("dest");
				String id = rs.getString("id");
				
		        row[i] = "Destination: " + dest + " | ID: " + id + "";
		        flights.add(row[i]);
		        i++;
			}

			rs.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return flights;
	}
	
	
	// Admin function
	public boolean deleteFlight(String tableName, String id) {
		try {
			String sql = "DELETE FROM " + tableName + " WHERE id='" + id + "'";
			stmt.executeUpdate(sql);
			JOptionPane.showMessageDialog(null, "Flight successfully deleted");
			return true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return false;
	}
}
