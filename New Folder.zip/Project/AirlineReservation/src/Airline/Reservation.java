package Airline;

public interface Reservation {
	public abstract void manageMainMenu();
}

