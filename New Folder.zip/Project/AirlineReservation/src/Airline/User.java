package Airline;

import java.awt.GridLayout;
import java.sql.SQLException;
import java.text.ParseException;

import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

public abstract class User implements Reservation {
	protected String username;
	protected String password;
	protected static String userType;

	
	/**
	 * Format a JOptionPane dialog box to have multiple user info data fields, 
	 * validate the input, and then send the input to the registerNewUser method 
	 * to add it to the database 
	 */
	protected void getUserRegistration() throws SQLException, ParseException, Exception {
		// Create the Airline Reservation application object
		AirlineReservation app = new AirlineReservation();
		
		String[] states = { "Select", "Alabama", "Alaska", "Arizona", "Arkansas", 
				"California", "Colorado", "Connecticut", "Delaware", "Florida", 
				"Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", 
				"Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", 
				"Massachusetts", "Michigan", "Minnesota", "Mississippi", 
				"Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", 
				"New Jersey", "New Mexico", "New York", "North Carolina", 
				"North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", 
				"Rhode Island", "South Carolina", "South Dakota", "Tennessee", 
				"Texas", "Utah", "Vermont", "Virginia", "Washington", "West "
				+ "Virginia", "Wisconsin", "Wyoming" };

		// Create formatting class object
		Formatting form = new Formatting();
	        
	    // Format the fields
	    JPanel controls = new JPanel(new GridLayout(0, 1, 2, 2));
	    JTextField inputFirst = new JTextField(30);
	    controls.add(inputFirst);
	    JTextField inputMiddle = new JTextField(30);
	    controls.add(inputMiddle);
	    JTextField inputLast = new JTextField(30);
	    controls.add(inputLast);
	    JTextField inputStreet = new JTextField(30);
	    controls.add(inputStreet);
	    JTextField inputCity = new JTextField(30);
	    controls.add(inputCity);
	    JComboBox<?> selectState = new JComboBox<Object>(states);
	    controls.add(selectState);
	    JTextField inputZip = new JTextField(30);
	    controls.add(inputZip);
	    JTextField inputUsername = new JTextField(20);
	    controls.add(inputUsername);
	    JTextField inputPassword = new JPasswordField(20);
	    controls.add(inputPassword);
	    JTextField inputEmail = new JTextField(30);
	    controls.add(inputEmail);
	    MaskFormatter mf = new MaskFormatter("###-##-####");
	    JFormattedTextField inputSSN = new JFormattedTextField(mf);
	    controls.add(inputSSN);	    
	    JTextField showSQ = new JTextField("What was the name "
	    		+ "of your first pet?");
	    showSQ.setEditable(false);
	    controls.add(showSQ);
	    JTextField inputANS = new JTextField();
	    controls.add(inputANS);
	    
	    // Display registration form
	    boolean cont = true;
	    int result;
		do {
			JPanel panel = form.getRegistrationForm(controls);
			
			// Display the dialog box
		    Object[] choices = { "Register", "Back To Menu" };
			Object defaultChoice = choices[0];
			result = JOptionPane.showOptionDialog(null, panel, "User Registration", 
					JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, 
					null, choices, defaultChoice);
			
			String[] userInput = new String[12];
			// Validate the user's selection and input
			if (result == JOptionPane.OK_OPTION) {
				userInput[0] = inputFirst.getText();
				userInput[1] = inputMiddle.getText();
				userInput[2] = inputLast.getText();
				userInput[3] = inputStreet.getText();
				userInput[4] = inputCity.getText();
				userInput[5] = (String) selectState.getSelectedItem();
				userInput[6] = inputZip.getText();
				userInput[7] = inputUsername.getText();
				userInput[8] = inputPassword.getText();
				userInput[9] = inputEmail.getText();
				userInput[10] = inputSSN.getText();
				userInput[11] = inputANS.getText();

				int count = 0;
				for (int i = 0; i < userInput.length; i++) {
					if (userInput[i].isEmpty() && i != 1) {
						// All fields are required except middle name
						count++;
					}
				}				
				if (count != 0) {
					JOptionPane.showMessageDialog(null,
							"Please fill in all of the data fields.",
							"Error", JOptionPane.ERROR_MESSAGE);
				}
				else {
					ValidateInput vi = new ValidateInput();
					if (vi.isValidAddress(userInput[3]) && 
							vi.isValidState(userInput[5]) && 
							vi.isValidZip(userInput[6]) &&
							vi.isValidUsername(userInput[7]) &&
							vi.isValidPassword(userInput[8]) &&
							vi.isValidEmail(userInput[9]) &&
							vi.isValidSSN(userInput[10])) {
						cont = false;
						DBConnection db = new DBConnection();
						boolean success = db.registerNewUser(userInput);
						if (success == true) {
							// Go to login screen
							app.procUserLogin();
						}
					}
				}
			}
			if (result == JOptionPane.CANCEL_OPTION || result == 1) {
				// Go back to main menu
				app.optionScreen();
			}
	    	if (result == JOptionPane.CLOSED_OPTION) {
	    		System.exit(0);  // Terminate the application
	    	}
		} while (cont == true);
 	}
}